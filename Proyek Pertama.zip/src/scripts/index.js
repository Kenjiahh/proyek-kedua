import '../styles/styles.css';
import App from './view/app';

const app = new App({
  drawerButton: document.getElementById('drawer-button'),
  navigationDrawer: document.getElementById('navigation-drawer'),
  content: document.getElementById('main-content'),
});

// Initial render
window.addEventListener('DOMContentLoaded', () => {
  app.renderPage();
});

// Handle hash change for SPA navigation
window.addEventListener('hashchange', () => {
  app.renderPage();
});